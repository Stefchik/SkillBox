print('Задача 8. Замечательные числа')
for number in range(10, 99):
  product_of_numbers = ((number % 10) * (number // 10)) * 3
  if (number == product_of_numbers):
    print(number)