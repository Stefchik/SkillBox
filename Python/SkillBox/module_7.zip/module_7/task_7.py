print('Задача 7. Отрезок')
number_1 = int(input('Напишите первое число: '))
number_2 = int(input('Напишите второе число: '))
average = 0
count = 0
for number in range(number_1, number_2 + 1):
  if (number % 3 == 0):
    count += 1
    average += number
print('Среднее арифметическое:', average / ((count)))