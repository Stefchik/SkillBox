print('Задача 4. С заботой о природе')
violation = 0
for count in range(30, 35 + 1):
  peoples = int(input(f' Людей в {count} секторе: '))
  if (peoples > 10):
    violation += 1
    print('Нарушение! Слишком много людей в секторе!')
  else:
    print('Всё спокойно.')
print('Количество нарушений:', violation)