print('Задача 2. Должники')
count = 0
for number in range(1, 10):
  number = int(input('Введите число: '))
  if (number % 2 == 0 and number > 0):
    count += 1
    print('Число подходит', number)
  else:
    print('Число не подходит')
print('Количество подходящий чисел', count)