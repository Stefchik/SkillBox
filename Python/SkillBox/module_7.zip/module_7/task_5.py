print('Задача 5. Факториал')
number = int(input('Введите число: '))
factorial = 1
for count in range(1, number + 1):
  factorial *= count
print('Факториал числа', number, 'равен', factorial)