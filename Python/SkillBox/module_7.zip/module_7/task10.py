print('Задача 10.')
number = int(input('Введите количество карточек всего: '))
total_summ = total_card = 0
for count in range (1, number + 1):
    total_summ += count
    if count < number:
        card = int(input('Введите номер оставшейся карточки: '))
        total_card += card
print('Номер потерянной карточки: ', total_summ - total_card)