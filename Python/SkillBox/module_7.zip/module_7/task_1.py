print('Задача 1. Тайны археологии')
for number in 114, 12, 14, 10605, 490, 7450:
  if (number % 2 == 0 and number // 3 != 0):
    print('Число подходит', number)
  else:
    print('Число не подходит', number)