print('Задача 3. Посчитай чужую зарплату...')
sum_salary = 0
for count in range(1, 12 + 1):
  salary = int(input(f'Напишите зарплату за {count} месяц: '))
  sum_salary += salary
print('Средняя зарплата за год равна:', sum_salary // 12)
