import task_1
print('---------------------------')
import task_2
print('---------------------------')
import task_3
print('---------------------------')
import task_4
print('---------------------------')
import task_5
print('---------------------------')
import task_6
print('---------------------------')
import task_7
print('---------------------------')
import task_8
print('---------------------------')
import task_9
print('---------------------------')
import task10
print('---------------------------')