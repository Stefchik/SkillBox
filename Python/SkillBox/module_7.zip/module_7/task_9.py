print('Задача 9. ...Теперь можно посчитать и свою')
last_salary = 0
increase = drop = 0
for counter in range (1, 11):
    salary = int(input(f'Введите {counter}-ю зарплату: '))
    if (salary > last_salary):
        increase += 1
    else:
        drop += 1
    last_salary = salary
    # print(increase, drop, last_ZP)
    
print('Зарплата бухгалтера росла:', increase, 'мес, падала:', drop, 'мес')
if(drop > 0):
    print('Числа не по возрастанию, наблюдалось падение ЗП! Пора валить.')
else:
    print('Числа по ворастанию, ЗП постоянно растёт!')
    
            
              
    