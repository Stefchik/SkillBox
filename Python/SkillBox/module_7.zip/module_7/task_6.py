print('Задача 6. Успеваемость в классе')
peoples = int(input('Количество учеников: '))
mark_3 = mark_4 = mark_5 = 0 
for count in range(1, peoples + 1):
  peoples_mark = int(input('Ученик получил оценку: '))
  if (peoples_mark == 3):
    mark_3 += 1
  elif (peoples_mark == 4):
    mark_4 += 1
  else:
    mark_5 += 1
if ((mark_5 > mark_4) and (mark_5 > mark_3)):
  print('Отличников больше всех')
elif((mark_4 > mark_5) and (mark_4 > mark_3)):
  print('Ударников больше всех')
else:
  print('Троечников больше всех')