import task_1
import task_2
import task_3
import task_4
import task_5
import task_6