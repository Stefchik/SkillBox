print('Задача 5. Счастливый билетик')
ticket = int(input('Введите номер билета (четное кол-во цифр): '))
count = 0
number_right_2  = 0
number_right_1 = 0
Sum_of_ticket_digits_1 = 0
Sum_of_ticket_digits_2 = 0
while (count != 6):
  if (count < 3):
    count += 1
    number_right_1 = ticket % 10 
    ticket //= 10
    Sum_of_ticket_digits_1 += number_right_1
  if (count >= 3):
    count += 1
    number_right_2 = ticket % 10 
    ticket //= 10
    Sum_of_ticket_digits_2 += number_right_2
if (Sum_of_ticket_digits_1 == Sum_of_ticket_digits_2):
  print('Выпал счастливый билетик')
else:
  print('Неудачный билет')
print()  