print('Задача 3. Слишком большие числа')
number = int(input('Введите число '))
count = 0
if (number == 0):
  count = 1
while (number != 0):
  count += 1
  number //= 10
print('В вашей числе,', count, 'цифры')