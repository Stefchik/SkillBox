print('Задача 8. Вклады')
deposit = int(input('Вклад в банке составляе, руб: '))
percent = int(input('Процентная ставка, %: '))
summ = int(input('Целевая сумма, руб: '))
year = 1
while deposit < summ:
    deposit += percent / 100 * deposit
    deposit //= 1
    year += 1
print('До желаемой суммы копить:', year, 'года/лет!')