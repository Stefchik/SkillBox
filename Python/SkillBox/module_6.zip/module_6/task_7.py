print('Задача 7. Обычный день на работе')
print('Начался 8-часовой рабочий день')
time = 0
sum_task = 0
wife = 0
while (time < 8):
  time += 1
  print(time, '-й час')
  task = int(input('Сколько задач решит Максим? '))
  sum_task += task
  wife += int(input('Звонит жена. Взять трубку? (1-да, 0-нет) '))
  print()
print('Рабочий день закончился. Всего выполнено задач:', sum_task)  
if (wife >= 1):
  print('Нужно зайти в магазин')