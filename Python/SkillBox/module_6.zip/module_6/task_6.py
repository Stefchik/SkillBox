print('Задача 6. Поставьте оценку!')
number_of_positive_numbers = 0
number_of_negative_numbers = 0
while True:
  number = int(input('Введите число: '))
  if (number > 0):
    number_of_positive_numbers += 1
  if (number < 0):
    number_of_negative_numbers += 1  
  if (number == 0):
    break
print('Кол-во положительных чисел:', number_of_positive_numbers)
print('Кол-во отрицательный чисел:', number_of_positive_numbers)