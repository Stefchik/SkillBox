print('Задача 4. Календари')
count = 0
while True:
  day_in_mounth = int(input('Введите количество дней: '))
  if (day_in_mounth == 0): break
  if (day_in_mounth % 2 == 0): count+= 1
print('Количество месяцев с четным количеством дней:', count)