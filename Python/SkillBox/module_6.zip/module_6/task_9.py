print('Задача 9. Игра «Угадай число»')
hidden_number = int(input('Загадали число: '))
count = 0
number = 0
while (number != hidden_number):
  number = int(input('Введите число: '))
  count += 1
  if (number < hidden_number):
    print('Число меньше, чем нужно. Попробуйте ещё раз! ')
  elif (number > hidden_number):
    print('Число больше, чем нужно. Попробуйте ещё раз! ')
print(' Вы угадали! Число попыток:', count)