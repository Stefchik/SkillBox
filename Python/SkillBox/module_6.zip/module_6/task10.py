print('Задача 10. Игра «Компьютер угадывает число»')
answer = 0
start = 1
end = 100

print('Загадайте число от 0 до 100 и я отгадаю его за 7 попыток или быстрее :)')
while answer != 1:    
    hypothesis = (start + end) // 2    
    print('Твое число равно, меньше или больше, чем число', hypothesis, '?')
    answer = int(input('Введите: 1 — равно, 2 — больше, 3 — меньше. '))
    if answer == 2:        
        start = hypothesis + 1        
    else:
        end =  hypothesis - 1        
print('Ваше число: ', hypothesis) 
