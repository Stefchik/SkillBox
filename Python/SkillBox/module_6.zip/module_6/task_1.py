print('Задача 1. Кубы чисел')
number = int(input('Введите число: '))
count = 1
while (count <= number):
  print(count, 'в 3 степени', count ** 3)
  count += 1