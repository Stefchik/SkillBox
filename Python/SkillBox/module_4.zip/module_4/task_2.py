print('Задача 2. Поступление')
russian_language = int(input('Введите количество баллов по русскому языку: '))
mathematics = int(input('Введите количество баллов по математике: '))
informatics = int(input('Введите количество баллов по информатике: '))
score = russian_language + mathematics + informatics
if score >= 270:
  print(' Поздравляю, ты поступил на бюджет!')
else:
  print('К сожалению, ты не прошёл на бюджет.')