print('Задача 6. Игра в кубики')
kostya = int(input('Кубик Кости: '))
owner = int(input('Кубик владельца: '))
if kostya >= owner:
  print('Разность:', kostya - owner)
  print('Костя платит')
else:
  print('Сумма:', kostya + owner)
  print('Владелец платит')
print('Игра окончена')