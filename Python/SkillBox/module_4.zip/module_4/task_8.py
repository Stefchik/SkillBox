print('Задача 8. Тяжёлая жизнь')
hours = int(input('Введите отработанные часы: '))
loan_balance = int(input('Введите остаток по кредиту: '))
spending_on_food= int(input('Введите траты на еду: '))
salary = ((200 * hours) / 2 ** 3) + hours
expenses = loan_balance + spending_on_food
if salary >= expenses:
  print('Часов хватает. Можно отдохнуть!')
else:
  print('Часов не хватает. Придется работать!')