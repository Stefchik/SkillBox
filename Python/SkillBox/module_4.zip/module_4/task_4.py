print('Задача 4. Калькулятор скидки')
cost_of_goods_1 = int(input('Стоимость первого товара? '))
cost_of_goods_2 = int(input('Стоимость второго товара? '))
cost_of_goods_3 = int(input('Стоимость третьего товара? '))
check_amount = cost_of_goods_1 + cost_of_goods_2 + cost_of_goods_3
discount = check_amount / 100 * 10
if check_amount > 10000:
  print('Стоимость со скидкой', check_amount - discount)
else:
  print('Стоимость без учета скидки', check_amount)