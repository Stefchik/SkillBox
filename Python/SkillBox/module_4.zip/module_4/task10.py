print('Задача 10. Максимальное число (по желанию)')
number_1 = int(input('Введите первое число: '))
number_2 = int(input('Введите второе число: '))
number_3 = int(input('Введите третье число: '))
if number_1 > number_2:
  max = number_1
else:
  max = number_2
if number_3 > max:
  max = number_3
print('Максимальное число:', max)  