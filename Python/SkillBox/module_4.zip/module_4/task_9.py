print('Задача 9. Плохой циферблат')
mileage = int(input('Введите пробег: '))
number = int(input('Введите сегодняшнее число: '))
num_1 = mileage // 100
num_2 = (mileage // 10) % 10
num_3 = mileage % 10
sum = num_1 + num_2 + num_3
if sum > number:
  print('Сброс.')
  mileage = 0
  print('Пробег:', mileage)
else:
  print('Сегодня не сломался')
  print('Пробег:', mileage)