print('Задача 5. Модуль числа')
number = int(input('Ввели '))
if number > 0:
  print('Ответ', number)
else:
  print('Ответ', number * (-1))