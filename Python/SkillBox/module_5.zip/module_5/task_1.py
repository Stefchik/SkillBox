print('Задача 1. Калькулятор опыта')
experience = int(input('Введите количество опыта: '))
level = 1
if experience < 1000:
  print('Ваш уровень:', level)
elif experience >= 1000 and experience < 2500:
  level += 1
  print('Ваш уровень:', level)
elif experience >= 2500 and experience < 5000:
  level += 2
  print('Ваш уровень:', level)
elif experience >= 5000:
  level += 3
  print('Ваш уровень:', level)