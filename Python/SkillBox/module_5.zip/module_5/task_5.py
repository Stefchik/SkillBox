print('Задача 5. Опять двойка')
rating = int(input('Что получил по математике? '))
if rating == 2 or rating == 3:
    print('Плохо. Марш учиться!')
elif rating == 4 or rating == 5:
    print('Молодец! Можешь отдохнуть.')