print('Задача 7. Костя хочет выигрывать')
number_1 = int(input('Введите первое число: '))
number_2 = int(input('Введите второе число: '))
number_3 = int(input('Введите третье число: '))
if number_1 == number_2 == number_3:
  print('Все совпадают:', 3)
elif number_1 != number_2 != number_3:
  print('Все числа различны', 0)
else:
  print('Два числа совпадают', 2)