print('Задача 6. Защита от дурака')
number = int(input("Введите число: "))
if (number < -9 and number > -100) or (number > 9 and number < 100):
  print("Число двухзначное")
else:
  print("Число не двухзначное")