print('Задача 9. Прогрессивный налог 2')
income = int(input('Доход: '))
tax_13 = income / 100 * 13
tax_20 = (income - 10000) * 20 / 100 + 10000 * 13 / 100
tax_30 = (income - 50000) * 30 / 100 + (50000 - 10000) * 20 / 100 + 10000 * 13 / 100
if income < 10000:
  print("Налог составит: ", tax_13)
elif income >= 10000 and income < 50000:
  print("Налог составит: ", tax_20)
else:
  print("Налог составит: ", tax_30)