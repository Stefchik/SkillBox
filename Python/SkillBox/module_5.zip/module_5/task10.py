print('Задача 10. Почта')
#1 Способ
hourse = int(input("Введите время в расах(от 0 до 23): "))
if (hourse >= 8) and (hourse < 10) or (hourse >= 12) and (hourse < 14) or (hourse >= 15) and (hourse < 18) or (hourse >= 20) and (hourse < 22):
  print("Можно получить посылку")
else:
  print("Посылку получить нельзя") 
#2 Способ
hourse = int(input("Введите время в расах(от 0 до 23): "))
if (hourse < 8) or (hourse >= 10) and (hourse < 12) or (hourse >= 14) and (hourse < 15) or (hourse >= 18) and (hourse < 20) or (hourse >= 22):
  print("Посылку получить нельзя")
else:
  print("Можно получить посылку") 