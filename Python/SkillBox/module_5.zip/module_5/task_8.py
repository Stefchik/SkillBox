print('Задача 8. Новоселье')
price = int(input('Стоимость квартиры: '))
s = int(input('Площадь квартиры: '))
if (s >= 100 and price <= 10) or (s >= 80 and price <= 7):
  print('Квартира подходит')
else:
  print('Квартира не подходит')