print('Задача 3. Функция')
x = int(input('Введите икс: '))
y = 0
if x > 0:
  y = x - 12
elif x == 0:
  y = 5
else:
  y = x ** 2
print('Игрек равен', y)