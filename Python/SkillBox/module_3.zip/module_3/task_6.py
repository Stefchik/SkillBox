print('Задача 6')
number_1 = int(input('Введите первое число: '))
number_2 = int(input('Введите второе число: '))
result = number_1 % 100 + number_2 % 100
print('Сумма:', result)