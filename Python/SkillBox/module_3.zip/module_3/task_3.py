print('Задача 3. Следующее и предыдущее')
number = int(input('Введите число: '))
next_number, previous_number = number + 1, number - 1
print('После числа', number, 'идет число', next_number)
print('До числа', number, 'идёт число', previous_number)