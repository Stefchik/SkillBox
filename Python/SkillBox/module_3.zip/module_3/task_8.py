print('Задача 8. Режем число на части')
number = int(input('Введите четырехзначное число: '))
num_1 = number // 1000
num_2 = (number // 100) % 10
num_3 = (number % 100) // 10
num_4 = number % 10
print('Ответ', num_1, num_2, num_3, num_4)