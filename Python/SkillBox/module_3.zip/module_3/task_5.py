print('Задача 5. Часы')
n = int(input('Введите количество минут: '))
time_in_hours, minutes = n // 60, n % 60
print('Ответ:',time_in_hours, 'часа', minutes, 'минут')