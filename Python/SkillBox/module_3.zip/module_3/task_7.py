print('Задача 7. Поездка по кругу')
speed = int(input('Введите скорость (км/ч): '))
time = int(input('Введите время (ч): '))
result = speed * time % 115
print('Ответ:', result)